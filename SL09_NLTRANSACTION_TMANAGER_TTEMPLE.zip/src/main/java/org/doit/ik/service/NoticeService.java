package org.doit.ik.service;

public interface NoticeService {
	
	
	
}
