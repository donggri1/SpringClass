package org.doit.ik.service;

public class NoticeServiceImpl {

}
