package org.doit.ik.domain;

public class Snippet {
	public static void main(String[] args) {
		org.doit.ik.domain
	}
}

