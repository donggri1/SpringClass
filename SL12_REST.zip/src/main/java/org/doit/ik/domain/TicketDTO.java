package org.doit.ik.domain;


import lombok.Data;
 
@Data
public class TicketDTO {
   
   private int tno;
   private String owner;
   private String grade; 
    
}